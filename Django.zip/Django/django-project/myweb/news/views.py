from django.shortcuts import render
from news.models import News