// Function to toggle the navigation menu for small screens
function toggleMenu() {
    var nav = document.getElementById('nav');
    nav.classList.toggle('active');
}

// Event listener for the menu toggle button
document.getElementById('menu-toggle').addEventListener('click', toggleMenu);
