from django.contrib import admin
from contactenquiry.models import contactEnquiry
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'mobile', 'msg')
admin.site.register(contactEnquiry, ContactAdmin)