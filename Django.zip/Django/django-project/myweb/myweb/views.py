from django.http import HttpResponse
from django.shortcuts import render
from .forms import UsersForms
from service.models import Service
from contactenquiry.models import contactEnquiry
from news.models import News
from django.core.paginator import Paginator





def homePage(request):
    newsData = News.objects.all()
    data={
       
        'newsData':newsData
        
    }
    return render(request,"index.html",data)






def aboutPage(request):
    return render(request,"aboutus.html")







def servicePage(request):
    serviceData= Service.objects.all()
    paginator= Paginator(serviceData,2)
    page_number = request.GET.get('page')
    ServiceDatafinal = paginator.get_page(page_number)
    totalpage= ServiceDatafinal.paginator.num_pages


    if request.method=='GET':
        st=request.GET.get('servicename')
        if st !=None:
            ServiceDatafinal= Service.objects.filter(service_title__icontains=st)
    data={
        # 'image1':'static\images\p1.jpg'
        'serviceData':ServiceDatafinal,
        'lastpage': totalpage,
        'totalpagelist':[n+1 for n in range(totalpage)]
        }
    return render(request,"service.html",data)





def contactPage(request):
    return render(request,"contact.html")


def saveEnquiry(request):
    if request.method=='POST':
        name =request.POST.get('name')
        email =request.POST.get('email')
        mobile =request.POST.get('mobile')
        message =request.POST.get('message')
        datasave=contactEnquiry(name=name, email=email,mobile=mobile,msg=message)
        datasave.save()
    return render(request,"contact.html")


def signIn(request):
    return render(request,"signin.html")






def userForm(request):
    fn = UsersForms
    ans=0
    data={'form':fn}
    try:
        if request.method == "POST":
            n1= int(request.POST.get("num1"))
            n2= int(request.POST.get("num2"))
            n3= int(request.POST.get("num3"))
            n4= int(request.POST.get("num4"))
            ans=n1+n2+n3+n4
            data={
                'form':fn,
                'output':ans
            }
    except:
        pass
    return render(request,"userform.html",data)







def calculator(request):
    newsData = News.objects.all()
    c=''
    
    try:
        if request.method=="POST":
            n1=eval(request.POST.get('num1'))
            n2=eval(request.POST.get('num2'))
            opr=request.POST.get('opr')
            if opr == "+":
                c=n1+n2
            elif opr == "-":
                c=n1-n2
            elif opr == "*":
                c=n1*n2
            elif opr == "/":
                c=n1/n2

    except:
        c= "invalid Operator......."
    print(c)
    return render(request,"calculator.html",{'c':c})







def shopNow(request,id):
    return render(request,"shopnow.html.html",{'Output': True })







def newsDetails(request, slug):
    newsDetails=News.objects.get(news_slug=slug)
    data  = {
        'newsDetails': newsDetails
    }
    return render(request,"newsdetails.html",data)





def saveevenodd(request):
    d=''
    if request.method == "POST":
        if request.POST.get('num1')=="":
            return render(request,"evenodd.html",{'error':True })
        n = eval(request.POST.get('num1'))
        if n % 2 == 0:
            d = "Even Number"
        else:
            d = "Odd Number"
    
    return render(request,"evenodd.html",{'Output':d })
    





def stdMarksheet(request):
    total_marks = 0
    hindi=0
    english=0
    math =0
    physics=0
    chemistry=0
    if request.method == "POST":
        hindi = int(request.POST.get('hindi'))
        english = int(request.POST.get('english'))
        math = int(request.POST.get('math'))
        physics = int(request.POST.get('physics'))
        chemistry = int(request.POST.get('chemistry'))
    
    total_marks = hindi+english+math+physics+chemistry

    return render(request, "marksheet.html", {"tmarks":total_marks})