from django import forms

class UsersForms(forms.Form):
    num1=forms.CharField()
    num2=forms.CharField()
    num3=forms.CharField()
    num4=forms.CharField()